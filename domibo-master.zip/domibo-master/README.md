Domibo
======

This bot is a continuation of Karl Marx's MarxBot from http://www.multiplayerpiano.com. Since Karl is no longer able to maintain this bot, I, Hri7566, have agreed to renew his code with his permission.

Karl will most likely not be returning in the near future. If he does, there is a big chance that he won't return to MPP, considering his previous thoughts on the community.
